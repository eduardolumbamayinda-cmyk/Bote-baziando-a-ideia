# Bote Baziando a Ideia — Android

Projeto Android pronto para abrir no Android Studio ou compilar no GitHub Actions.

## APK
O workflow `.github/workflows/build-apk.yml` gera `app-debug.apk` automaticamente.

## Funcionalidades atuais
- Ideia/projeto com armazenamento local
- Painel de IA (protótipo local)
- Plano de 7 dias
- Ideias de divulgação
- Estratégia de vendas
- Lista de tarefas
- Controle de receitas/despesas em Kz
- Interface mobile em português

## Próxima fase
Ligar a uma API de IA real, dados de oportunidades e notificações.
